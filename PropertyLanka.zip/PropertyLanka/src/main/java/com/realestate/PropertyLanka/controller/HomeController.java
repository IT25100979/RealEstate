package com.realestate.PropertyLanka.controller;

import com.realestate.PropertyLanka.service.PropertyService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @Autowired
    private PropertyService propertyService;

    @GetMapping("/")
    public String showHomePage(HttpSession session, Model model) {
        model.addAttribute("allProperties", propertyService.getAllProperties());
        model.addAttribute("user", session.getAttribute("loggedInUser"));
        return "index";
    }
}
